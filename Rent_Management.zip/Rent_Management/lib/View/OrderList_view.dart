import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rent_management/Controllers/signup_controller.dart';

import 'Order_place _View.dart';

class OrderListView extends StatelessWidget {
  final List<List<User>> userListData = [
    [
      User(name: 'John Doe', age: 30),
      User(name: 'Jane Smith', age: 25),
      User(name: 'Alice Johnson', age: 35),
    ],
    [
      User(name: 'Bob Brown', age: 40),
      User(name: 'Emma Watson', age: 28),
      User(name: 'Michael Clark', age: 45),
    ],
    [
      User(name: 'Sarah Parker', age: 35),
      User(name: 'David Wilson', age: 32),
      User(name: 'Linda Evans', age: 38),
    ],
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: GetBuilder<SignupController>(
        init: SignupController(),
        builder: (controller) {
          return Stack(
            children: [
              Container(
                alignment: Alignment.topCenter,
                height: Get.height * 0.350,
                width: Get.width,
                decoration: const BoxDecoration(
                  color: Colors.redAccent,
                  borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(24),
                    bottomLeft: Radius.circular(24),
                  ),
                ),
                child: Padding(
                  padding: EdgeInsets.only(top: Get.height * 0.050),
                  child: Text(
                    "Order List",
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              Center(
                child: Padding(
                  padding: EdgeInsets.only(
                    top: Get.height * 0.120,
                    bottom: Get.height * 0.060,
                    left: 16,
                    right: 16,
                  ),
                  child: SingleChildScrollView(
                    child: Container(
                      padding: EdgeInsets.all(16),
                      height: 1100,
                      width: Get.width,
                      decoration: BoxDecoration(
                        color: Colors.grey.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(28),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          ListView.builder(
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemCount: userListData.length,
                            itemBuilder: (context, index) {
                              return Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Divider(
                                    height: 30,
                                    color: Colors.grey,
                                    thickness: 2.0,
                                  ),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                      vertical: 8.0,
                                      horizontal: 16.0,
                                    ),
                                    child: Row(
                                      children: [
                                        Text(
                                          'List ${index + 1}',
                                          style: TextStyle(
                                            fontSize: 18.0,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        SizedBox(width: 8.0),
                                        Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            IconButton(
                                              icon: Icon(Icons.picture_as_pdf),
                                              onPressed: () {
                                                // Add PDF button functionality here
                                              },
                                            ),
                                            IconButton(
                                              icon: Icon(Icons.notifications),
                                              onPressed: () {
                                                // Add Notice button functionality here
                                              },
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                  ListView.builder(
                                    shrinkWrap: true,
                                    physics: NeverScrollableScrollPhysics(),
                                    itemCount: userListData[index].length,
                                    itemBuilder: (context, subIndex) {
                                      return Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          ListTile(
                                            title: Text(userListData[index][subIndex].name),
                                            subtitle: Text('Age: ${userListData[index][subIndex].age}'),
                                          ),
                                        ],
                                      );
                                    },
                                  ),
                                ],
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 20.0,
                right: 20.0,
                child: FloatingActionButton(
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => OrderPlaceView()));
                  },
                  child: Icon(Icons.add),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class User {
  final String name;
  final int age;

  const User({required this.name, required this.age});
}
