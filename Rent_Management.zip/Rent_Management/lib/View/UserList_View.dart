import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rent_management/Controllers/signup_controller.dart';
import 'Master_form_view.dart';
 // Corrected import name

class UserListView extends StatelessWidget {
  final List<User> users = [
    User(name: 'John Doe', age: 30),
    User(name: 'Jane Smith', age: 25),
    User(name: 'Alice Johnson', age: 35),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: GetBuilder<SignupController>(
        init: SignupController(),
        builder: (controller) {
          return Stack(
            children: [
              Container(
                alignment: Alignment.topCenter,
                height: Get.height * 0.350,
                width: Get.width,
                decoration: const BoxDecoration(
                  color: Colors.redAccent,
                  borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(24),
                    bottomLeft: Radius.circular(24),
                  ),
                ),
                child: Padding(
                  padding: EdgeInsets.only(top: Get.height * 0.050),
                  child: Text(
                    "User List",
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              Center(
                child: Padding(
                  padding: EdgeInsets.only(
                    top: Get.height * 0.120,
                    bottom: Get.height * 0.060,
                    left: 16,
                    right: 16,
                  ),
                  child: SingleChildScrollView(
                    child: Container(
                      padding: EdgeInsets.all(16),
                      height: 1100,
                      width: Get.width,
                      decoration: BoxDecoration(
                        color: Colors.grey.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(28),
                      ),
                      child: ListView.builder(
                        itemCount: users.length,
                        itemBuilder: (context, index) {
                          return UserItem(user: users[index]);
                        },
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 20.0,
                right: 20.0,
                child: FloatingActionButton(
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context) => MasterFormView()));
                  },
                  child: Icon(Icons.add),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class User {
  final String name;
  final int age;

  const User({required this.name, required this.age});
}

class UserItem extends StatelessWidget {
  final User user;

  const UserItem({required this.user});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(user.name),
      subtitle: Text('Age: ${user.age}'),
    );
  }
}
