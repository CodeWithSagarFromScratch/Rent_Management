import 'package:flutter/material.dart';

class ReceiptViewPage extends StatefulWidget {
  @override
  _ReceiptViewPageState createState() => _ReceiptViewPageState();
}

class _ReceiptViewPageState extends State<ReceiptViewPage> {
  // List of names
  final List<String> names = [
    'John Doe',
    'Jane Smith',
    'Alice Johnson',
    'Bob Brown',
    'Emma Watson',
    'Michael Clark',
    'Sarah Parker',
    'David Wilson',
    'Linda Evans',
  ];

  // Filtered names based on search query
  List<String> filteredNames = [];

  @override
  void initState() {
    // Initially, set filteredNames to contain all names
    filteredNames.addAll(names);
    super.initState();
  }

  // Method to filter names based on search query
  void filterNames(String query) {
    setState(() {
      filteredNames = names.where((name) => name.toLowerCase().contains(query.toLowerCase())).toList();
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Receipt List'),
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(8.0),
            child: TextField(
              onChanged: filterNames,
              decoration: InputDecoration(
                labelText: 'Search',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filteredNames.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: Text(filteredNames[index]),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
