import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:rent_management/Constant/image_path_constant.dart';
import 'package:rent_management/Constant/textstyle_constant.dart';

import 'package:rent_management/View/UserList_View.dart';

import 'MenuBar_ItemList_View.dart';
import 'OrderList_view.dart';
import 'Receipt_Search_View.dart';

class CatageryScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text('Dashbord'),
        ),
        drawer: Drawer(
          child: Container(
            width: MediaQuery.of(context).size.width * 0.7,
            // Adjusted width
            child: MenuBarItemList(),
          ),
        ),
        body: HomePage(),
      ),
      routes: {
        '/offlineCourses': (context) => UserListView(),
        '/onlineCourses': (context) => OrderListView(),
        '/Receipt': (context) => ReceiptViewPage(),
      },
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        children: [
          CarouselSlider(
            options: CarouselOptions(
              height: 200.0,
              enlargeCenterPage: true,
              autoPlay: true,
              aspectRatio: 16 / 9,
              autoPlayCurve: Curves.bounceOut,
              enableInfiniteScroll: true,
              autoPlayAnimationDuration: Duration(milliseconds: 200),
              viewportFraction: 1,
            ),
            items: [
              'assets/adavnceimage.jpeg',
              'assets/chatgpt.jpeg',
              'assets/gglimage.jpeg',
            ].map((item) {
              return Builder(
                builder: (BuildContext context) {
                  return Container(
                    width: MediaQuery.of(context).size.width,
                    margin: EdgeInsets.symmetric(horizontal: 5.0),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8.0),
                      image: DecorationImage(
                        image: AssetImage(item),
                        fit: BoxFit.cover,
                      ),
                    ),
                  );
                },
              );
            }).toList(),
          ),
          Divider(
            height: 70,
          ),
          Padding(
            padding: const EdgeInsets.only(top: 70.0),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  SizedBox(width: 20),
                  CategoryItem(
                    imagePath: ImagePathConstant.user,
                    description: 'Users',
                    route: '/offlineCourses',
                  ),
                  SizedBox(width: 25),
                  CategoryItem(
                    imagePath: ImagePathConstant.Order,
                    description: 'Order',
                    route: '/onlineCourses',
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 10),
          CategoryItem(
            imagePath: ImagePathConstant.Receipt,
            description: 'Receipt',
            route: '/Receipt',
          ),
        ],
      ),
    );
  }
}

class CategoryItem extends StatelessWidget {
  final String imagePath;
  final String description;
  final String route;

  const CategoryItem({
    required this.imagePath,
    required this.description,
    required this.route,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        Navigator.pushNamed(context, route);
      },
    child: Container(
    decoration: BoxDecoration(
    borderRadius: BorderRadius.circular(8.0),
    boxShadow: [
    BoxShadow(
    color: Colors.grey.withOpacity(0.5),
    spreadRadius: 5,
    blurRadius: 7,
    offset: Offset(0, 3), // changes position of shadow
    ),
    ],
    ),
      child: Column(
        children: [
          Image.asset(
            imagePath,
            width: 150,
            height: 150,
          ),
          SizedBox(height: 10),
          Text(description,style: TextStyleConstant.semiBold16(),),
        ],
      ),
    ) );
  }
}
