import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rent_management/Constant/color_constant.dart';
import 'package:rent_management/Constant/image_path_constant.dart';
import 'package:rent_management/Constant/layout_constant.dart';
import 'package:rent_management/Constant/textstyle_constant.dart';
import 'package:rent_management/Controllers/signup_controller.dart';
import 'package:rent_management/Services/form_validation_services.dart';
import 'package:rent_management/Widgets/custom_button.dart';
import 'package:rent_management/Widgets/custom_textfield.dart';


class UserProFileView extends StatelessWidget {
  const UserProFileView({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: GetBuilder<SignupController>(
          init: SignupController(),
          builder: (controller) {
            return Stack(
              children: [
                Container(
                  alignment: Alignment.topCenter,
                  height: Get.height * 0.350,
                  width: Get.width,
                  decoration: const BoxDecoration(
                      color: ColorConstant.redAccent,
                      borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(24),
                          bottomLeft: Radius.circular(24))),
                  child: Padding(
                    padding: EdgeInsets.only(top: Get.height * 0.050),
                    child: Text(
                      "Profile",
                      style:
                      TextStyleConstant.bold30(color: ColorConstant.white),
                    ),
                  ),
                ),
                Center(
                  child: Padding(
                    padding: EdgeInsets.only(
                        top: Get.height * 0.120,
                        bottom: Get.height * 0.060,
                        left: screenWidthPadding,
                        right: screenWidthPadding),
                    child: SingleChildScrollView(
                      child: Container(
                        padding: screenPadding,
                         height: Get.height,

                        width: Get.width,
                        decoration: BoxDecoration(
                            color: ColorConstant.lightGrey.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(28)),
                        child: Form(
                          key: controller.formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Align(
                                alignment: Alignment.center,
                                child: Image.asset(
                                  ImagePathConstant.logo1,
                                  height: Get.height * 0.080,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                    top: Get.height * 0.020,
                                    bottom: Get.height * 0.006),
                                child: Text(
                                  " UserName",
                                  style: TextStyleConstant.semiBold16(),
                                ),
                              ),
                              Container(
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10.0), // Set circular border radius
                                  color: Colors.white, // Set white background color
                                  border: Border.all(color: Colors.black), // Set border color
                                ),

                                child: DropdownButtonFormField<String>(
                                  decoration: InputDecoration( // Optional: You can also add padding to the dropdown field
                                    contentPadding: EdgeInsets.symmetric(horizontal: 16.0),
                                    border: InputBorder.none, // Hide default border
                                  ),

                                  hint: Text('Select lister'),
                                  onChanged: (value) {
                                    // Handle selected value here
                                  },
                                  items: [
                                    DropdownMenuItem(
                                      value: 'Customer 1',
                                      child: Text('Customer 1'),
                                    ),
                                    DropdownMenuItem(
                                      value: 'Customer 2',
                                      child: Text('Customer 2'),
                                    ),
                                    // Add more DropdownMenuItem for each customer
                                  ],
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please select a customer';
                                    }
                                    return null;
                                  },
                                ),
                              ),


                              Padding(
                                padding: EdgeInsets.only(
                                    top: Get.height * 0.020,
                                    bottom: Get.height * 0.006),
                                child: Text(
                                  "Rent",
                                  style: TextStyleConstant.semiBold16(),
                                ),
                              ),
                              TextField(
                                decoration: InputDecoration(
                                  hintText: "Enter Rent Amount",
                                  prefixIcon: Icon(Icons.real_estate_agent),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: BorderSide(
                                      color: Colors.white, // set the border color
                                      width: 2.0, // set the border width
                                    ),
                                  ),
                                  filled: true, // fill the TextField background with a color
                                  fillColor: Colors.white, // set the background color
                                ),
                                keyboardType: TextInputType.text,
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                    top: Get.height * 0.020,
                                    bottom: Get.height * 0.006),
                                child: Text(
                                  "Date",
                                  style: TextStyleConstant.semiBold16(),
                                ),
                              ),
                              TextField(
                                decoration: InputDecoration(
                                  hintText: "Enter Date ",
                                  prefixIcon: Icon(Icons.real_estate_agent),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                    borderSide: BorderSide(
                                      color: Colors.white, // set the border color
                                      width: 2.0, // set the border width
                                    ),
                                  ),
                                  filled: true, // fill the TextField background with a color
                                  fillColor: Colors.white, // set the background color
                                ),
                                keyboardType: TextInputType.text,
                              ),




                              // Padding(
                              //   padding: EdgeInsets.only(top: Get.height * 0.040),
                              //   child: Row(
                              //     mainAxisAlignment: MainAxisAlignment.center,
                              //     children: [
                              //       Text("Already have an account  ",
                              //           style: TextStyleConstant.medium16()),
                              //       GestureDetector(
                              //         onTap: () => Get.back(),
                              //         child: Text("Login",
                              //             style: TextStyleConstant.semiBold18(
                              //                 color: ColorConstant.redAccent)),
                              //       ),
                              //     ],
                              //   ),
                              // ),
                              const Spacer(),
                              Align(
                                alignment: Alignment.center,
                                child: CustomButton(
                                  title: "Save",
                                  onTap: () {
                                    if (controller.formKey.currentState!
                                        .validate()) {
                                      controller.postSignup();
                                    }
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            );
          }),
    );
  }
}
