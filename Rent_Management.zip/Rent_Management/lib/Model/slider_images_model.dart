import 'dart:convert';

GetBannerImagesModel getBannerImagesModelFromJson(String str) =>
    GetBannerImagesModel.fromJson(json.decode(str));

String getBannerImagesModelToJson(GetBannerImagesModel data) =>
    json.encode(data.toJson());

class GetBannerImagesModel {
  String? statusCode;
  String? message;
  List<SliderList>? sliderList;

  GetBannerImagesModel({
    this.statusCode,
    this.message,
    this.sliderList,
  });

  factory GetBannerImagesModel.fromJson(Map<String, dynamic> json) =>
      GetBannerImagesModel(
        statusCode: json["status_code"],
        message: json["message"],
        sliderList: List<SliderList>.from(
            json["slider_list"].map((x) => SliderList.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
    "status_code": statusCode,
    "message": message,
    "slider_list": (sliderList != null)
        ? List<dynamic>.from(sliderList!.map((x) => x.toJson()))
        : null,
  };
}

class SliderList {
  String? slideId;
  String? bannerImage;

  SliderList({
    this.slideId,
    this.bannerImage,
  });

  factory SliderList.fromJson(Map<String, dynamic> json) => SliderList(
    slideId: json["slide_id"],
    // Prepend the base URL to the slider image
    bannerImage: "https://rentswale.com/admin/uploads/${json["slider_image"]}",
  );

  Map<String, dynamic> toJson() => {
    "id": slideId,
    "baner_image": bannerImage,
  };
}

