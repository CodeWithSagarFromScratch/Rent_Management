import 'dart:convert';

PostLoginModel postLoginModelFromJson(String str) =>
    PostLoginModel.fromJson(json.decode(str));

String postLoginModelToJson(PostLoginModel data) => json.encode(data.toJson());

class PostLoginModel {
  String? statusCode;
  Result? result;
  String? message;

  PostLoginModel({this.statusCode, this.result, this.message});

  factory PostLoginModel.fromJson(Map<String, dynamic> json) => PostLoginModel(
      statusCode: json["Status_code"],
      result: Result.fromJson(json["result"]),
      message: json["message"]);

  Map<String, dynamic> toJson() => {
        "Status_code": statusCode,
        "result": result?.toJson(),
        "message": message
      };
}

class Result {
  String? id;
  String? name;
  String? emailAddress;
  String? username;
  String? type;
  String? password;

  Result({
    this.id,
    this.name,
    this.emailAddress,
    this.username,
    this.type,
    this.password,
  });

  factory Result.fromJson(Map<String, dynamic> json) => Result(
        id: json["id"],
        name: json["name"],
        emailAddress: json["email_address"],
        username: json["username"],
        type: json["type"],
        password: json["password"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "name": name,
        "email_address": emailAddress,
        "username": username,
        "type": type,
        "password": password,
      };
}
