import 'dart:convert';
import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:rent_management/Constant/endpoint_constant.dart';
import 'package:rent_management/Constant/storage_key_constant.dart';
import 'package:rent_management/Model/get_material_required_model.dart';
import 'package:rent_management/Model/post_material_item_model.dart';
import 'package:rent_management/Services/http_services.dart';
import 'package:rent_management/Services/storage_services.dart';
import 'package:rent_management/Widgets/custom_loader.dart';
import 'package:rent_management/Widgets/custom_toast.dart';


class MaterialRequiredController extends GetxController {
  GetMaterialRequiredModel getMaterialRequiredModel =
      GetMaterialRequiredModel();
  PostMaterialItemModel postMaterialItemModel = PostMaterialItemModel();

  TextEditingController quantityController = TextEditingController();

  RxList<Map> createdMaterialItemList = <Map>[].obs;
  RxString selectMaterial = "Select Material".obs;
  RxString selectUnit = "".obs;
  RxString selectId = "Id".obs;
  RxString selectCategory = "Category".obs;
  RxString selectCode = "Code".obs;
  RxString siteName = "".obs;
  RxString siteCode = "".obs;
  RxString userName = "".obs;

  final formKey = GlobalKey<FormState>();

  @override
  void onInit() {
    super.onInit();
    initialFunctioun();
  }

  initialFunctioun() async {
    siteName.value = await StorageServices.getData(
            prefKey: StorageKeyConstant.siteName,
            dataType: StorageKeyConstant.stringType) ??
        "Site name";
    siteCode.value = await StorageServices.getData(
            prefKey: StorageKeyConstant.siteCode,
            dataType: StorageKeyConstant.stringType) ??
        "Site code";
    userName.value = await StorageServices.getData(
        prefKey: StorageKeyConstant.loginId,
        dataType: StorageKeyConstant.stringType);

    await getMaterialRequiredItemList();
  }

  Future getMaterialRequiredItemList() async {
    CustomLoader.openCustomLoader();

    var response = await HttpServices.getHttpMethod(
        url: EndPointConstant.materialRequirementItem);

    log("Get material required item list response ::: $response");

    getMaterialRequiredModel =
        getMaterialRequiredModelFromJson(response["body"]);

    try {
      if (getMaterialRequiredModel.statusCode == "200" ||
          getMaterialRequiredModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
        update();
      } else {
        CustomLoader.closeCustomLoader();
      }
    } catch (error, st) {
      CustomLoader.closeCustomLoader();
      log("Something went wrong during getting material required items list ::: $error");
      log("Error location during getting material required items list ::: $st");
    }
  }

  Future postCreatedMaterialItemList() async {
    CustomLoader.openCustomLoader();

    Map<String, dynamic> payload = {
      "site_code": siteCode.value,
      "site_name": siteName.value,
      "username": userName.value,
      "remark": "Remark",
      "order_item": await "${jsonEncode(createdMaterialItemList)}",
    };

    log("Post create material item list payload ::: $payload");

    var response = await HttpServices.postHttpMethod(
        url: EndPointConstant.materialOrder, payload: payload);

    log("Post material required item list response ::: $response");

    postMaterialItemModel = postMaterialItemModelFromJson(response["body"]);

    try {
      if (postMaterialItemModel.statusCode == "200" ||
          postMaterialItemModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
        customToast(message: "${postMaterialItemModel.message}");
        createdMaterialItemList.clear();
        update();
      } else {
        CustomLoader.closeCustomLoader();
        CustomLoader.closeCustomLoader();
        customToast(message: "${postMaterialItemModel.message}");
      }
    } catch (error, st) {
      CustomLoader.closeCustomLoader();
      log("Something went wrong during posting material required items list ::: $error");
      log("Error location during posting material required items list::: $st");
    }
  }
}
