import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:rent_management/Constant/endpoint_constant.dart';
import 'package:rent_management/Constant/storage_key_constant.dart';
import 'package:rent_management/Model/post_login_model.dart';
import 'package:rent_management/Services/http_services.dart';
import 'package:rent_management/Services/storage_services.dart';
import 'package:rent_management/View/Dashbord_View.dart';
import 'package:rent_management/Widgets/custom_loader.dart';
import 'package:rent_management/Widgets/custom_toast.dart';


class LoginController extends GetxController {
  PostLoginModel postLoginModel = PostLoginModel();

  TextEditingController phoneController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  final formKey = GlobalKey<FormState>();

  Future<void> postLogin() async {
    try {
      CustomLoader.openCustomLoader();

      Map<String, dynamic> payload = {
        "username": phoneController.text,
        "password": passwordController.text,
      };

      log("Post login payload ::: $payload");

      var response = await HttpServices.postHttpMethod(
          url: EndPointConstant.login, payload: payload);

      postLoginModel = postLoginModelFromJson(response["body"]);

      if (postLoginModel.statusCode == "200" ||
          postLoginModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
        log('Login successful. Navigating to BottomBarView...');
        await StorageServices.setData(
            dataType: StorageKeyConstant.boolType,
            prefKey: StorageKeyConstant.isAuthenticate,
            boolData: true);
        await StorageServices.setData(
            dataType: StorageKeyConstant.stringType,
            prefKey: StorageKeyConstant.name,
            stringData: "${postLoginModel.result?.name}");
        await StorageServices.setData(
            dataType: StorageKeyConstant.stringType,
            prefKey: StorageKeyConstant.userId,
            stringData: "${postLoginModel.result?.id}");
        await StorageServices.setData(
            dataType: StorageKeyConstant.stringType,
            prefKey: StorageKeyConstant.userName,
            stringData: "${postLoginModel.result?.username}");
        await StorageServices.setData(
            dataType: StorageKeyConstant.stringType,
            prefKey: StorageKeyConstant.email,
            stringData: "${postLoginModel.result?.emailAddress}");
        await StorageServices.setData(
            dataType: StorageKeyConstant.stringType,
            prefKey: StorageKeyConstant.userType,
            stringData: "${postLoginModel.result?.type}");

        customToast(message: "${postLoginModel.message}");
      //   Get.offAll(() => MasterFormView());
       //  Get.offAll(() => DashboardViewSection());
         Get.offAll(() => CatageryScreen());
      } else {
        CustomLoader.closeCustomLoader();
        customToast(message: "${postLoginModel.message}");
        // Get.offAll(() => MasterFormView());
       //  Get.offAll(() => DashboardViewSection());
          Get.offAll(() => CatageryScreen());
      }
    } catch (error) {
      CustomLoader.closeCustomLoader();
      log("Something went wrong during login ::: $error");
    }
  }
}
