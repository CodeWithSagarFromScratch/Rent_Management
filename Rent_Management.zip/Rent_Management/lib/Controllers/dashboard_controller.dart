import 'package:get/get.dart';
import 'package:flutter/cupertino.dart';
import 'package:rent_management/Constant/endpoint_constant.dart';
import 'package:rent_management/Model/slider_images_model.dart';
import 'package:rent_management/Services/http_services.dart';
import 'package:rent_management/Widgets/custom_loader.dart';


class DashboardController extends GetxController {
  GetBannerImagesModel getBannerImagesModel = GetBannerImagesModel();

  // GetBranchListModel getBranchListModel = GetBranchListModel();

  @override
  void onInit() {
    super.onInit();
    getBannerImages();

  }

  Future getBannerImages() async {
    try {
      CustomLoader.openCustomLoader();
      // Map<String, String> payload = {"type": "Type1"};

      var response =
          await HttpServices.getHttpMethod(url: EndPointConstant.slider);

      debugPrint("Get banner images response ::: $response");

      getBannerImagesModel = getBannerImagesModelFromJson(response["body"]);

      if (getBannerImagesModel.statusCode == "200" ||
          getBannerImagesModel.statusCode == "201") {
        CustomLoader.closeCustomLoader();
        update();
      } else {
        CustomLoader.closeCustomLoader();
        debugPrint(
            "Something went wrong during getting banner images ::: ${getBannerImagesModel.message}");
      }
    } catch (error) {
      CustomLoader.closeCustomLoader();
      debugPrint(
          "Something went wrong during getting banner images ::: $error");
    }
  }

}
