import 'package:fluttertoast/fluttertoast.dart';

customToast({required String message}) {
  return Fluttertoast.showToast(msg: message);
}
