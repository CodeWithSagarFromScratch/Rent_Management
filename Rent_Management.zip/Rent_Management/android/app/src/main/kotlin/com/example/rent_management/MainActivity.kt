package com.example.rent_management

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
